class  naveen
{
	public static void main(String[] args) 
	{
		String name= "nabeen";
		System.out.println(name);
	}
}
