 /*wap to store employees name,job role,company name and package and print the output in the below format...My self Raja working in IBM and earning 3.25LPA*/
class EmployeeDetails 
{
	public static void main(String[] args) 
	{
		String employeeName = "Naveen";
		String designation = "Hr";
		String nameOfTheCompany = "Capgemini";
		double salary = 3.25;
		System.out.println("Myself "+employeeName+" working as " +designation+ " in "+nameOfTheCompany+" and earning "+salary+"LPA");
	}
}
