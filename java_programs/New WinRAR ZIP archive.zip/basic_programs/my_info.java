/*WAP to store yourname,company name,salary and print proper output*/
class my_info
{
	public static void main(String[] args) 
	{
		String name="Naveen";
		String companyname="capgemini";
		double salary=5.5;
		System.out.println("my name is "+name+" working in "+companyname+" with "+salary+" lpa");
		
	}
}
