/*WAP to store the the data and print*/
class program3
{
	public static void main(String[] args) 
	{
		int n = 56;
		double value=89.1;
		String subject="naveen";
		boolean flag=true;
		char ch='@';
		System.out.println(n);
		System.out.println(value);
		System.out.println(subject);
		System.out.println(flag);
		System.out.println(ch);
	}
}
