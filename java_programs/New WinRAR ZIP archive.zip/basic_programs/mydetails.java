/*WAP to store your name,degree percentage,yop,email id and print all the valuse*/
class mydetails
{
	public static void main(String[] args) 
	{
		String name="Naveen";
		double percentage=71.4;
		int yop=2020;
		String email="1998naveennavi@gmail.com";
		System.out.println("my name is "+name);
		System.out.println(percentage+" is my degree percentage");
		System.out.println("I passed in the year "+yop);
		System.out.println("please contact "+email);
	}
}
