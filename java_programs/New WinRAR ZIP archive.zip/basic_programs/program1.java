class program1 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println(100);
		System.out.println(8.1);
		System.out.println('*');
		System.out.println(true);
		System.out.println("hi");
	}
}
