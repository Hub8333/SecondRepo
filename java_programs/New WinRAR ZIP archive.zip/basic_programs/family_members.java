/*wap to store your name ,father name,mother name and print with meaningful message*/
class family_members
{
	public static void main(String[] args) 
	{
		String name="Naveen";
		String fathername="Venkateswarlu";
		String mothername="Pushpavathi";
		System.out.println("Iam "+ name+ " son of "+fathername+" and "+mothername);
	}
}
