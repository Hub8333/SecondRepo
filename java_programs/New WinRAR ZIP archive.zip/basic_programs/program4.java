/*wap to store your name,age,height,last letter of your name and print it*/
class myinfo
{
	public static void main(String[] args) 
	{
		String name="naveen";
		int age=23;
		double height=5.9;
		char letter='n';
		System.out.println("My name is" + name);
		System.out.println(age+"is my age");
		System.out.println("My height is"+height);
		System.out.println("My name last letter is"+letter);
	}
}
