/*wap to store your name,branch,percentage and print the output in the below format*/ 
class myresult 
{
	public static void main(String[] args) 
	{
		String name = "naveen";
        String branch = "mechanical";
		double percentage = 71.1;
		System.out.println(name+" is a "+ branch+" student"+" with"+percentage+"%");
	}
}
