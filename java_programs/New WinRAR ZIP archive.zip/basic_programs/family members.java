/*wap to store your name ,father name,mother name and print with meaningful message*/
class family members
{
	public static void main(String[] args) 
	{
		String name="Naveen";
		String father name="Venkateswarlu";
		String mother name="Pushpavathi";
		System.out.println("My name is"+ name);
		System.out.println("My father name is"+ father name);
		System.out.println("My mother name is "+ mother name);
	}
}
