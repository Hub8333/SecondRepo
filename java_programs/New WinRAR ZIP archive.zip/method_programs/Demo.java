/*wap to create 2 methods and call the methods from main method*/
class Demo 
{
	public static void main(String[] args) 
	{
		System.out.println("start main...");
		walk();
		System.out.println("stop main...");
	}
	public static void walk()
	{
		System.out.println("A walk to remember");
	}
}
