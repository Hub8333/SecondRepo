/*wap to create 2 methods and call the methods from main method*/
class Run 
{
	public static void main(String[] args) 
	{
		System.out.println("main start");
		walk();
		swim();
		System.out.println("main end");
	}
	public static void walk()
	{
		System.out.println("move 5 km...");
	}
	public static void swim()
	{
		System.out.println("swim across the river...");
	}
}
