class Sample 
{
	public static void main(String[] args) 
	{
		System.out.println("Main Start...");
		Sample obj=new Sample();
		obj.jump();
		System.out.println("Main End...");
	}
	public void jump()
	{
		System.out.println("jump from tree...");
	}
}
