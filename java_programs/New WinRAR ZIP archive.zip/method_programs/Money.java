class Money
{
	public static void main(String[] args) 
	{
		System.out.println("Start Main...");
        language();
        select();
        enter();
		take();
		System.out.println("End Main...");
	}
	public static void language()
	{
		System.out.println("Select The Language");
	}
	public static void select()
	{
		System.out.println("Select Withdraw");
	}
	public static void enter()
	{
		System.out.println("Enter The Pin");
	}
	public static void take()
	{
		System.out.println("Collec The Money");
	}
}
