class Sample 
{
	public static void main(String[] args) 
	{
		System.out.println("Main Starts...");
		System.out.println(Demo.i);
		Demo d1 = new Demo();
		System.out.println(d1.j);
		System.out.println("Main Ends...");
	}
}
