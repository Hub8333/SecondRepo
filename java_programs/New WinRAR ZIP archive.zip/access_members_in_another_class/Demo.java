class Demo 
{
	public static int i = 56;
	public int j = 34;
}
