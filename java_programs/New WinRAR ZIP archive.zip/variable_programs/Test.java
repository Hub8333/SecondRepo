class Test  
{
	public static int z=56;
	public static void main(String[] args) 
	{
		System.out.println(z);
	}
}
