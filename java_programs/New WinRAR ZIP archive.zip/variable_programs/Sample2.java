/*WAP to create 2 static variables of different datatype and access to print 
both the variables in main method*/
class Sample2 
{
	public static int k=100;
	public static double h=5.9;
	public static void main(String[] args) 
	{
		System.out.println(k);
		System.out.println(h);
	}
}
