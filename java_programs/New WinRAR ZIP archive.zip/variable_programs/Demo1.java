class Demo1 
{
	public static void main(String[] args) 
	{
		result();
		Demo1 obj=new Demo1();
		obj.length();
	}
	public static void result()
	{
		 boolean pass=true;
		System.out.println(pass);
	}
	public void length()
	{
	    double height=5.9;
		System.out.println(height);
	}
}
