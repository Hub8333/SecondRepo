class Test1 
{
	public static int a;/* Global variable will be initialized to default value by compiler */
	public static double h;
	public static char c;
	public static String name;
	public static boolean status;

	public static void main(String[] args) 
	{ 
		System.out.println(a);
		System.out.println(h);
		System.out.println(c);
		System.out.println(name);
		System.out.println(status);
	}
}
