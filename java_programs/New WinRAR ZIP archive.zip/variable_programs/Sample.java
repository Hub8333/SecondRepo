class Sample 
{
	public static void main(String[] args) 
	{
		int a;/* All the local variables must be initialized and use further
		without initializing, if we use local variable, we will get error*/ 
		System.out.println(a);
	}
}
