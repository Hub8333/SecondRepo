class Sample1 
{
	public int k=99;
	public static void main(String[] args) 
	{
		Sample1 s1=new Sample1();
		System.out.println(s1.k );
	}
}
