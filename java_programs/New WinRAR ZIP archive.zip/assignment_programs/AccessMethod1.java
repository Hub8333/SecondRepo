/*WAP to create static method and non static method and call in another class main method*/
class  AccessMethod1
{
	public static void run()
	{
		System.out.println("Hi Jspiders");
	}
	public void run1()
	{
		System.out.println("Bye Jspiders");
	}
}
