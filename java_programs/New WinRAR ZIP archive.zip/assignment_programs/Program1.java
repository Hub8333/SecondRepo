class Program1 
{
	public static String name = "mounika";
	public String n="naveen";
	public static void main(String[] args) 
	{
		Program1 p1=new Program1();
		System.out.println(name);
		System.out.println(p1.n);
	}
}
