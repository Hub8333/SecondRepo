/*create 1st class with static variable and non static variable of sam datatype
          2nd class with static method and non static method
		  3rd class with static variable,non static variable, static method and non static method
		  
		  print 1st class static variable in 2nd class static method
		  print 2nd class non static variable in 2nd class non static method
		  print 3rd class static var in same class static method
		  print 3rd class non static var in same class non static method

		  create 4th class for main method
		  call 2nd and 3rd class static and non static method in the main method*/
class Run 
{
	public static int i = 1500;
	public int j = 1200;
	  
}
