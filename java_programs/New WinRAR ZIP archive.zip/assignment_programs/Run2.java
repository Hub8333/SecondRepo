class Run2 
{
	public static int i = 150;
	public boolean status = false;

	public static void main()
	{
		System.out.println(i);
	}
	public void main1()
	{
		System.out.println(status);
	}

	
}
