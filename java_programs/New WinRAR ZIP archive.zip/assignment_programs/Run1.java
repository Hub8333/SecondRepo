class Run1 
{
	public static void run()
	{
		System.out.println(Run.i);
	}
	public void run1()
	{
		Run obj = new Run();
		System.out.println(obj.j);
	}
	
}
