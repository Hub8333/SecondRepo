/*WAP to create class variable, instance variable,class method, instance method and access all the members in another class main method*/
class AccessMethod3 
{
	public static int a = 100;
	public boolean status = false;

	public static void main() 
	{
		System.out.println("Fly High");
	}
	public void main1()
	{
		System.out.println("Walk For 5 kms");
	}
}
