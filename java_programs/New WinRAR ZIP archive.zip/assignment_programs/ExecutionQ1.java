class ExecutionQ1 
{
	public static int a = 100;
	public String name = "jspiders";


	public static void main(String[] args) 
	{
		System.out.println("Main Starts...");
		int i = 100;
		System.out.println(i);
		System.out.println(a);
		ExecutionQ1 obj = new ExecutionQ1();
		System.out.println(obj.name);
		System.out.println("Main Ends...");
	}
}
