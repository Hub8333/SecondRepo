class Program2 
{
	public static double height=5.9;
	public boolean status=false;
	public static void main(String[] args) 
	{
		System.out.println(height);
		Program2 p2=new Program2();
		System.out.println(p2.status);
	}
}
