class Program3 
{
	public static char z='i';
	public static String name="love";
    public char c='*';
	public String place="hyderabad";
	public static void main(String[] args) 
	{
		System.out.println(z);
		System.out.println(name);
		Program3 p3=new Program3();
		System.out.println(p3.c);
		System.out.println(p3.place);
	}
}
